# API endpoints for Telegram Mini App
