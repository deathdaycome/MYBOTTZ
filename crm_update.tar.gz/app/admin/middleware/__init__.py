# app/admin/middleware/__init__.py
from .roles import RoleMiddleware

__all__ = ['RoleMiddleware']
