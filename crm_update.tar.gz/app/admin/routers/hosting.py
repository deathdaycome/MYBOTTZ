"""
Роутер для управления Timeweb хостингом
"""

from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import Optional, List
from datetime import datetime, timedelta
from pydantic import BaseModel

from ...database.database import get_db
from ...database.models import AdminUser, HostingServer, HostingPayment, Project, User
from ...database.crm_models import Client
from ..middleware.auth import get_current_admin_user
from ..navigation import get_navigation_items

router = APIRouter(prefix="/hosting", tags=["hosting"])
templates = Jinja2Templates(directory="app/admin/templates")


# === Pydantic Models ===

class ServerCreate(BaseModel):
    project_id: Optional[int] = None
    client_id: Optional[int] = None
    client_name: str
    client_company: Optional[str] = None
    client_telegram_id: Optional[int] = None
    server_name: str
    configuration: Optional[str] = None
    ip_address: Optional[str] = None
    cost_price: float
    client_price: float
    service_fee: float = 0
    start_date: datetime
    next_payment_date: datetime
    payment_period: str = "monthly"
    notes: Optional[str] = None


class PaymentCreate(BaseModel):
    server_id: int
    amount: float
    payment_date: Optional[datetime] = None
    expected_date: datetime
    period_start: datetime
    period_end: datetime
    status: str = "pending"
    payment_method: Optional[str] = None
    notes: Optional[str] = None


# === HTML Pages ===

@router.get("/", response_class=HTMLResponse)
async def hosting_page(
    request: Request,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Страница управления хостингом"""
    try:
        return templates.TemplateResponse(
            "hosting.html",
            {
                "request": request,
                "user": current_user,
                "navigation_items": get_navigation_items("/admin/hosting")
            }
        )
    except Exception as e:
        return f"Ошибка загрузки страницы хостинга: {e}"


# === API Endpoints ===

@router.get("/api/stats")
async def get_hosting_stats(
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Получить статистику по хостингу"""
    try:
        now = datetime.utcnow()

        # Общее количество активных серверов
        active_servers = db.query(HostingServer).filter(
            HostingServer.status == "active"
        ).count()

        # Прибыль за текущий месяц
        current_month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        # Получаем все активные серверы для расчета прибыли
        servers = db.query(HostingServer).filter(
            HostingServer.status == "active"
        ).all()

        total_profit_month = sum([
            (s.client_price + (s.service_fee or 0) - s.cost_price)
            for s in servers
        ])

        # Прибыль за всё время (из платежей)
        all_payments = db.query(HostingPayment).filter(
            HostingPayment.status == "paid"
        ).all()

        total_profit_all_time = 0
        for payment in all_payments:
            server = db.query(HostingServer).filter(HostingServer.id == payment.server_id).first()
            if server:
                # Прибыль = платеж - себестоимость
                profit = payment.amount - server.cost_price
                total_profit_all_time += profit

        # Просрочки
        overdue_count = db.query(HostingServer).filter(
            HostingServer.next_payment_date < now,
            HostingServer.status.in_(["active", "overdue"])
        ).count()

        overdue_sum = 0
        overdue_servers = db.query(HostingServer).filter(
            HostingServer.next_payment_date < now,
            HostingServer.status.in_(["active", "overdue"])
        ).all()

        for server in overdue_servers:
            overdue_sum += server.client_price + (server.service_fee or 0)

        return {
            "success": True,
            "stats": {
                "active_servers": active_servers,
                "profit_month": round(total_profit_month, 2),
                "profit_all_time": round(total_profit_all_time, 2),
                "overdue_count": overdue_count,
                "overdue_sum": round(overdue_sum, 2)
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения статистики: {str(e)}")


@router.get("/api/servers")
async def get_servers(
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Получить список серверов"""
    try:
        query = db.query(HostingServer)

        # Фильтр по статусу
        if status:
            query = query.filter(HostingServer.status == status)

        servers = query.order_by(HostingServer.next_payment_date.asc()).all()

        return {
            "success": True,
            "servers": [server.to_dict() for server in servers],
            "total": len(servers)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения серверов: {str(e)}")


@router.get("/api/server/{server_id}")
async def get_server(
    server_id: int,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Получить информацию о сервере"""
    server = db.query(HostingServer).filter(HostingServer.id == server_id).first()

    if not server:
        raise HTTPException(status_code=404, detail="Сервер не найден")

    # Получаем платежи
    payments = db.query(HostingPayment).filter(
        HostingPayment.server_id == server_id
    ).order_by(HostingPayment.expected_date.desc()).all()

    return {
        "success": True,
        "server": server.to_dict(),
        "payments": [payment.to_dict() for payment in payments]
    }


@router.post("/api/server")
async def create_server(
    data: ServerCreate,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Создать новый сервер"""
    try:
        server = HostingServer(
            project_id=data.project_id,
            client_id=data.client_id,
            client_name=data.client_name,
            client_company=data.client_company,
            client_telegram_id=data.client_telegram_id,
            server_name=data.server_name,
            configuration=data.configuration,
            ip_address=data.ip_address,
            cost_price=data.cost_price,
            client_price=data.client_price,
            service_fee=data.service_fee,
            start_date=data.start_date,
            next_payment_date=data.next_payment_date,
            payment_period=data.payment_period,
            status="active",
            notes=data.notes
        )

        db.add(server)
        db.commit()
        db.refresh(server)

        # Создаем первый платеж (ожидается)
        payment = HostingPayment(
            server_id=server.id,
            amount=data.client_price + data.service_fee,
            expected_date=data.next_payment_date,
            period_start=data.start_date,
            period_end=data.next_payment_date,
            status="pending"
        )
        db.add(payment)
        db.commit()

        return {
            "success": True,
            "server": server.to_dict(),
            "message": "Сервер успешно добавлен"
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Ошибка создания сервера: {str(e)}")


@router.put("/api/server/{server_id}")
async def update_server(
    server_id: int,
    data: ServerCreate,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Обновить информацию о сервере"""
    server = db.query(HostingServer).filter(HostingServer.id == server_id).first()

    if not server:
        raise HTTPException(status_code=404, detail="Сервер не найден")

    try:
        server.project_id = data.project_id
        server.client_id = data.client_id
        server.client_name = data.client_name
        server.client_company = data.client_company
        server.client_telegram_id = data.client_telegram_id
        server.server_name = data.server_name
        server.configuration = data.configuration
        server.ip_address = data.ip_address
        server.cost_price = data.cost_price
        server.client_price = data.client_price
        server.service_fee = data.service_fee
        server.start_date = data.start_date
        server.next_payment_date = data.next_payment_date
        server.payment_period = data.payment_period
        server.notes = data.notes
        server.updated_at = datetime.utcnow()

        db.commit()
        db.refresh(server)

        return {
            "success": True,
            "server": server.to_dict(),
            "message": "Сервер успешно обновлен"
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Ошибка обновления сервера: {str(e)}")


@router.delete("/api/server/{server_id}")
async def delete_server(
    server_id: int,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Удалить сервер"""
    server = db.query(HostingServer).filter(HostingServer.id == server_id).first()

    if not server:
        raise HTTPException(status_code=404, detail="Сервер не найден")

    try:
        db.delete(server)
        db.commit()

        return {
            "success": True,
            "message": "Сервер удален"
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Ошибка удаления сервера: {str(e)}")


@router.post("/api/payment")
async def create_payment(
    data: PaymentCreate,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Зарегистрировать платеж"""
    try:
        payment = HostingPayment(
            server_id=data.server_id,
            amount=data.amount,
            payment_date=data.payment_date or datetime.utcnow(),
            expected_date=data.expected_date,
            period_start=data.period_start,
            period_end=data.period_end,
            status=data.status,
            payment_method=data.payment_method,
            notes=data.notes
        )

        db.add(payment)

        # Обновляем дату следующего платежа у сервера
        if data.status == "paid":
            server = db.query(HostingServer).filter(HostingServer.id == data.server_id).first()
            if server:
                # Рассчитываем следующий платеж в зависимости от периодичности
                if server.payment_period == "monthly":
                    next_date = data.period_end + timedelta(days=30)
                elif server.payment_period == "quarterly":
                    next_date = data.period_end + timedelta(days=90)
                elif server.payment_period == "yearly":
                    next_date = data.period_end + timedelta(days=365)
                else:
                    next_date = data.period_end + timedelta(days=30)

                server.next_payment_date = next_date
                server.status = "active"

        db.commit()
        db.refresh(payment)

        return {
            "success": True,
            "payment": payment.to_dict(),
            "message": "Платеж зарегистрирован"
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Ошибка регистрации платежа: {str(e)}")


@router.get("/api/calendar")
async def get_payment_calendar(
    month: Optional[int] = None,
    year: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Получить данные для календаря платежей"""
    try:
        now = datetime.utcnow()
        target_month = month or now.month
        target_year = year or now.year

        # Диапазон дат для выбранного месяца
        month_start = datetime(target_year, target_month, 1)
        if target_month == 12:
            month_end = datetime(target_year + 1, 1, 1)
        else:
            month_end = datetime(target_year, target_month + 1, 1)

        # Получаем платежи за месяц
        payments = db.query(HostingPayment).filter(
            and_(
                HostingPayment.expected_date >= month_start,
                HostingPayment.expected_date < month_end
            )
        ).all()

        # Получаем информацию о серверах
        calendar_data = []
        for payment in payments:
            server = db.query(HostingServer).filter(HostingServer.id == payment.server_id).first()
            if server:
                # Определяем цвет
                if payment.status == "paid":
                    color = "green"
                elif payment.expected_date < now and payment.status != "paid":
                    color = "red"
                elif (payment.expected_date - now).days <= 3:
                    color = "yellow"
                else:
                    color = "blue"

                calendar_data.append({
                    "id": payment.id,
                    "title": f"{server.client_name} - {server.server_name}",
                    "date": payment.expected_date.strftime("%Y-%m-%d"),
                    "amount": payment.amount,
                    "status": payment.status,
                    "color": color,
                    "server_id": server.id
                })

        return {
            "success": True,
            "calendar": calendar_data,
            "month": target_month,
            "year": target_year
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения календаря: {str(e)}")


@router.get("/api/clients/search")
async def search_clients(
    q: str,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Поиск клиентов для автодополнения"""
    try:
        clients = db.query(Client).filter(
            or_(
                Client.name.ilike(f"%{q}%"),
                Client.company.ilike(f"%{q}%")
            )
        ).limit(10).all()

        return {
            "success": True,
            "clients": [{
                "id": client.id,
                "name": client.name,
                "company": client.company,
                "telegram_id": client.telegram_id
            } for client in clients]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка поиска клиентов: {str(e)}")


@router.get("/api/projects")
async def get_active_projects(
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Получить список активных проектов для выбора"""
    try:
        projects = db.query(Project).filter(
            Project.status.in_(["in_progress", "new", "review", "accepted", "testing"])
        ).order_by(Project.created_at.desc()).all()

        return {
            "success": True,
            "projects": [{
                "id": p.id,
                "title": p.title,
                "status": p.status,
                "user_id": p.user_id,
                "client_telegram_id": p.client_telegram_id
            } for p in projects]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения проектов: {str(e)}")


@router.get("/api/project/{project_id}")
async def get_project_data(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: AdminUser = Depends(get_current_admin_user),
):
    """Получить данные проекта для автозаполнения формы сервера"""
    try:
        project = db.query(Project).filter(Project.id == project_id).first()

        if not project:
            raise HTTPException(status_code=404, detail="Проект не найден")

        # Получаем данные клиента (пользователя) из проекта
        user = db.query(User).filter(User.id == project.user_id).first()

        if not user:
            return {
                "success": False,
                "error": "Клиент проекта не найден"
            }

        # Формируем имя клиента
        client_name = user.full_name or user.first_name or user.username or "Клиент"

        return {
            "success": True,
            "project": {
                "id": project.id,
                "title": project.title,
                "user_id": project.user_id,
                "client_name": client_name,
                "client_telegram_id": project.client_telegram_id or user.telegram_id,
                "estimated_cost": project.estimated_cost
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения данных проекта: {str(e)}")
